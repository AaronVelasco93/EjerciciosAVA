var ws;
var jugador={
  "numJugador":0,
  "jugador":"nombre",
  "conectado":false,
  "tirada":0
};

  window.onload = function(e) {
    ws = io.connect('http://localhost:8082');

    ws.on('connect', function () {
      console.log('conectado');
      ws.on('respServer',function(data){
        console.log('La resspuesta de servidor fue:'+data);
      });
    });
  };

function iniciarJuego(){
  console.log('Solicitando inicio de juego');
  ws.emit('iniciaJuego',jugador);
}
