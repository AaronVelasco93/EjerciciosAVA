var socketServer = require('socket.io').listen(8082);
var juego={
  "nombre":"Mi jueguito",
  "iniciado":false,
  jugadores:[
    {
      "numJugador":0,
      "jugador":"nombre",
      "conectado":false,
      "tirada":0
    },
    {
      "numJugador":0,
      "jugador":"nombre",
      "conectado":false,
      "tirada":0
    }
  ]
};


socketServer.on('connect', function(socketClient) {
  console.log('Cliente conectado al juego');
  socketServer.emit('respServer','Estas conectado al servidor del juego');

  socketClient.on('iniciaJuego',function(data){
      console.log(data);
  });


});
