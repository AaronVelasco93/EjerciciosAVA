var socketServer = require('socket.io').listen(8082);
var juego={
  "nombre":"Mi jueguito",
  "iniciado":false,
  jugadores:[
    {
      "numJugador":0,
      "jugador":"nombre",
      "conectado":false,
      "tirada":0
    },
    {
      "numJugador":0,
      "jugador":"nombre",
      "conectado":false,
      "tirada":0
    }
  ]
};


socketServer.on('connect', function(socketClient) {
  console.log('Cliente conectado al juego');
  socketServer.emit('respServer','Estas conectado al servidor del juego');

  socketClient.on('iniciaJuego',function(data){
      console.log(data);
      if(!juego.iniciado){
        juego.iniciado=true;
        juego.jugadores[0].numJugador=1;
        juego.jugadores[0].jugador="Jugador 1",
        juego.jugadores[0].conectado=true;
        socketServer.emit('iniciaJuegoResponse',juego.jugadores[0]);
      }else{
        juego.jugadores[1].numJugador=2;
        juego.jugadores[1].jugador="Jugador 2",
        juego.jugadores[1].conectado=true;
        socketServer.emit('iniciaJuegoResponse',juego.jugadores[1]);
      }
      console.log(juego);
  });


});
