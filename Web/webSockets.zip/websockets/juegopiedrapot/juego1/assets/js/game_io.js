var ws;
var jugador={
  "numJugador":0,
  "jugador":"nombre",
  "conectado":false,
  "tirada":0
};

  window.onload = function(e) {
    ws = io.connect('http://localhost:8082');

    ws.on('connect', function () {
      console.log('conectado');
      ws.on('respServer',function(data){
        console.log('La resspuesta de servidor fue:'+data);
      });
    ws.on('iniciaJuegoResponse',function(data){
      console.log('Respuesta del servidor !!!');
      if( jugador.numJugador==0 ){
        jugador=data;
        console.log(jugador);
      }

    });
    });
  };

function iniciarJuego(){
  console.log('Solicitando inicio de juego');
  ws.emit('iniciaJuego',jugador);
}

function chkJug(){
  console.log('----- INFO del Jugador local -------');
  console.log(jugador);
}
