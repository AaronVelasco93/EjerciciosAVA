var ws;
var jugador={
  "numJugador":0,
  "jugador":"nombre",
  "conectado":false,
  "tirada":0
};
var seSolicitoInicio=false;

var imagenesIzq=["./assets/images/piedra_izq.png","./assets/images/papel_izq.png","./assets/images/tijeras_izq.png"];
var imagenesDer=["./assets/images/piedra_der.png","./assets/images/papel_der.png","./assets/images/tijeras_der.png"];



  window.onload = function(e) {
    ws = io.connect('http://localhost:8082');

    ws.on('connect', function () {
      console.log('conectado');
      ws.on('respServer',function(data){
        console.log('La resspuesta de servidor fue:'+data);
      });

    ws.on('iniciaJuegoResponse',function(data){
      console.log('Respuesta del servidor !!!');
      console.log(jugador);
      if(seSolicitoInicio){
        jugador=data;
        seSolicitoInicio=false;
        console.log(jugador);
      }

    });

    ws.on('tiroJug1Response',function(data){
        if(jugador.numJugador==1){
            console.log('jugador 1 tiro, pintar del lado izq');
            var imagen= document.createElement("img");
            imagen.setAttribute("src", imagenesIzq[data.tirada]);
            imagen.setAttribute("height", 200);
            imagen.setAttribute("width", 300);
            imagen.setAttribute("id", "imagenIzqierda");
            document.getElementById("jugLocal").appendChild(imagen);
        }else{
          var imagen= document.createElement("img");
          imagen.setAttribute("src", imagenesDer[data.tirada]);
          imagen.setAttribute("height", 200);
          imagen.setAttribute("width", 300);
          imagen.setAttribute("id", "imagenDerecha");
          document.getElementById("jugRemoto").appendChild(imagen);
          console.log('pintar del lado derecho');
        }
    });

    ws.on('tiroJug2Response',function(data){
      if(jugador.numJugador==2){
          console.log('jugador 2 tiro, pintar del lado izq');
          var imagen= document.createElement("img");
          imagen.setAttribute("src", imagenesIzq[data.tirada]);
          imagen.setAttribute("height", 200);
          imagen.setAttribute("width", 300);
          imagen.setAttribute("id", "imagenIzqierda");
          document.getElementById("jugLocal").appendChild(imagen);
      }else{
        var imagen= document.createElement("img");
        imagen.setAttribute("src", imagenesDer[data.tirada]);
        imagen.setAttribute("height", 200);
        imagen.setAttribute("width", 300);
        imagen.setAttribute("id", "imagenDerecha");
        document.getElementById("jugRemoto").appendChild(imagen);
        console.log('pintar del lado derecho');
      }
        
    });


    });
  };

function iniciarJuego(){
  console.log('Solicitando inicio de juego');
  seSolicitoInicio=true;
  ws.emit('iniciaJuego',jugador);
}

function chkJug(){
  console.log('----- INFO del Jugador local -------');
  console.log(jugador);
}

function tirar(){
  aleatorio=parseInt(((Math.random()*3)));
  console.log(aleatorio);

  if (jugador.numJugador==1) {
    ws.emit('tiroJug1',{"tirada":aleatorio});
  }else if (jugador.numJugador==2) {
    ws.emit('tiroJug2',{"tirada":aleatorio});
  }
}
