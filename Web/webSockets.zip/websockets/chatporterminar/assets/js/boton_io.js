var chat;
var data={
        "nick":"no name",
        "mensaje":"No message"
      };

  window.onload = function(e) {
    chat = io.connect('http://localhost:8082');
    chat.on('connect', function () {
      console.log('conectado');
      chat.emit('saluda','hola servidor');
      chat.on('respServer',function(data){
        console.log('La resspuesta de servidor fue:'+data);
      });

    });

  };

function mandarMensaje(){
  console.log('en la funcion mandar mensaje :)');
  data.nick=document.getElementById("nick").value;
  data.mensaje=document.getElementById("nick").value;
  chat.emit('mensaje',data);
}
