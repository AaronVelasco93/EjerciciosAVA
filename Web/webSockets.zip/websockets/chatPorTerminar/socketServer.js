var socketServer = require('socket.io').listen(8082);

socketServer.on('connect', function(socketClient) {
  console.log('Cliente conectado taller 4');
  socketServer.emit('respServer','Estas conectado al servidor principal');

  // cuando el cliente manda el evento 'saluda'
  socketClient.on('mensaje',function(data){
      console.log(data);
      socketServer.emit('nuevoMensaje',data);
  });

});
