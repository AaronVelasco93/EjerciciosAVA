var nombre="";
var nombres=[];
var nombresJson=[];
var direcciones=[{}];



function saludar(){
	console.log(nombre);
	nombre=document.getElementById("nombre").value;
	//alert("hola mundo:"+nombre);
	console.log(nombre);

	nombres.push("Maria");
	nombres.push("MArcos");
	nombres.push("Moises");
	nombres.push("Miriam");
	nombres.push("David");

	console.log(nombres);
	console.log(nombres.slice(1));
	console.log(nombres.slice(1,4));

	nombresJson.push({
						"id":1,
						"nombre":"jesus",
						"edad":33,
						"computadoras":[{"tipo":"casa","marca":"HP"},
										{"tipo":"trabajo","marca":"Apple"}
										]
					 });
		nombresJson.push({
						"id":2,
						"nombre":"MArcelo",
						"edad":60,
						"computadoras":[{"tipo":"casa","marca":"Apple"},
										{"tipo":"trabajo","marca":"mounstro"},
										{"tipo":"hobby","marca":"compaq"}
										]
					 	});
		console.log(nombresJson);

		console.log(document);

}

